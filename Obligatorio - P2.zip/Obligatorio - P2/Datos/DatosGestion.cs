using System;
using System.Data;
using Microsoft.Data.SqlClient;
using Entities;

namespace Datos
{
    public class DatosGestion
    {
        public int GuardarCliente(Cliente cliente)
        {
            using SqlConnection conexion = new SqlConnection(Constantes.CONNECTION_STRING);
            conexion.Open();

            using SqlCommand existe = new SqlCommand(
                "SELECT COUNT(*) FROM Clientes WHERE Documento = @Documento", conexion);
            existe.Parameters.AddWithValue("@Documento", cliente.Documento);
            if (Convert.ToInt32(existe.ExecuteScalar()) > 0)
                return -1;

            const string consulta = @"INSERT INTO Clientes
                (Tipo, Documento, Nombre, Telefono, Email, Direccion, Empresa)
                VALUES (@Tipo, @Documento, @Nombre, @Telefono, @Email, @Direccion, @Empresa)";

            using SqlCommand comando = new SqlCommand(consulta, conexion);
            comando.Parameters.AddWithValue("@Tipo", cliente.Tipo);
            comando.Parameters.AddWithValue("@Documento", cliente.Documento);
            comando.Parameters.AddWithValue("@Nombre", cliente.Nombre);
            comando.Parameters.AddWithValue("@Telefono", cliente.Telefono);
            comando.Parameters.AddWithValue("@Email", cliente.Email);
            comando.Parameters.AddWithValue("@Direccion", cliente.Direccion);
            comando.Parameters.AddWithValue("@Empresa", cliente.Empresa);
            return comando.ExecuteNonQuery();
        }

        public int ModificarCliente(Cliente cliente)
        {
            const string consulta = @"UPDATE Clientes SET Tipo=@Tipo, Documento=@Documento,
                Nombre=@Nombre, Telefono=@Telefono, Email=@Email, Direccion=@Direccion
                WHERE IdCliente=@IdCliente";
            using SqlConnection conexion = new SqlConnection(Constantes.CONNECTION_STRING);
            using SqlCommand comando = new SqlCommand(consulta, conexion);
            comando.Parameters.AddWithValue("@IdCliente", cliente.Id);
            comando.Parameters.AddWithValue("@Tipo", cliente.Tipo);
            comando.Parameters.AddWithValue("@Documento", cliente.Documento);
            comando.Parameters.AddWithValue("@Nombre", cliente.Nombre);
            comando.Parameters.AddWithValue("@Telefono", cliente.Telefono);
            comando.Parameters.AddWithValue("@Email", cliente.Email);
            comando.Parameters.AddWithValue("@Direccion", cliente.Direccion);
            conexion.Open();
            return comando.ExecuteNonQuery();
        }

        public int EliminarCliente(int idCliente)
        {
            using SqlConnection conexion = new SqlConnection(Constantes.CONNECTION_STRING);
            using SqlCommand comando = new SqlCommand(
                "DELETE FROM Clientes WHERE IdCliente=@IdCliente", conexion);
            comando.Parameters.AddWithValue("@IdCliente", idCliente);
            conexion.Open();
            return comando.ExecuteNonQuery();
        }

        public DataTable ListarClientes()
        {
            using SqlConnection conexion = new SqlConnection(Constantes.CONNECTION_STRING);
            using SqlDataAdapter adaptador = new SqlDataAdapter("SELECT * FROM Clientes", conexion);
            DataTable tabla = new DataTable();
            adaptador.Fill(tabla);
            return tabla;
        }

        // DEPÓSITOS: se asume que IdDeposito es una columna IDENTITY en SQL Server.
        public int GuardarDeposito(Deposito deposito)
        {
            const string consulta = @"INSERT INTO Depositos (Nombre, Ubicacion, Observaciones)
                VALUES (@Nombre, @Ubicacion, @Observaciones)";
            using SqlConnection conexion = new SqlConnection(Constantes.CONNECTION_STRING);
            using SqlCommand comando = new SqlCommand(consulta, conexion);
            comando.Parameters.AddWithValue("@Nombre", deposito.Nombre);
            comando.Parameters.AddWithValue("@Ubicacion", deposito.Ubicacion);
            comando.Parameters.AddWithValue("@Observaciones", deposito.Observaciones);
            conexion.Open();
            return comando.ExecuteNonQuery();
        }

        public DataTable ListarDepositosTabla()
        {
            using SqlConnection conexion = new SqlConnection(Constantes.CONNECTION_STRING);
            using SqlDataAdapter adaptador = new SqlDataAdapter(
                "SELECT IdDeposito, Nombre, Ubicacion, Observaciones FROM Depositos ORDER BY IdDeposito", conexion);
            DataTable tabla = new DataTable();
            adaptador.Fill(tabla);
            return tabla;
        }

        public List<Deposito> ListarDepositos()
        {
            var depositos = new List<Deposito>();
            const string consulta = @"SELECT IdDeposito, Nombre, Ubicacion, Observaciones
                FROM Depositos ORDER BY Nombre";
            using SqlConnection conexion = new SqlConnection(Constantes.CONNECTION_STRING);
            using SqlCommand comando = new SqlCommand(consulta, conexion);
            conexion.Open();
            using SqlDataReader lector = comando.ExecuteReader();
            while (lector.Read())
            {
                depositos.Add(new Deposito
                {
                    Id = Convert.ToInt32(lector["IdDeposito"]),
                    Nombre = Convert.ToString(lector["Nombre"]) ?? "",
                    Ubicacion = Convert.ToString(lector["Ubicacion"]) ?? "",
                    Observaciones = Convert.ToString(lector["Observaciones"]) ?? ""
                });
            }
            return depositos;
        }

        public int ModificarDeposito(Deposito deposito)
        {
            const string consulta = @"UPDATE Depositos SET Nombre=@Nombre, Ubicacion=@Ubicacion,
                Observaciones=@Observaciones WHERE IdDeposito=@IdDeposito";
            using SqlConnection conexion = new SqlConnection(Constantes.CONNECTION_STRING);
            using SqlCommand comando = new SqlCommand(consulta, conexion);
            comando.Parameters.AddWithValue("@IdDeposito", deposito.Id);
            comando.Parameters.AddWithValue("@Nombre", deposito.Nombre);
            comando.Parameters.AddWithValue("@Ubicacion", deposito.Ubicacion);
            comando.Parameters.AddWithValue("@Observaciones", deposito.Observaciones);
            conexion.Open();
            return comando.ExecuteNonQuery();
        }

        public int EliminarDeposito(int idDeposito)
        {
            using SqlConnection conexion = new SqlConnection(Constantes.CONNECTION_STRING);
            using SqlCommand comando = new SqlCommand(
                "DELETE FROM Depositos WHERE IdDeposito=@IdDeposito", conexion);
            comando.Parameters.AddWithValue("@IdDeposito", idDeposito);
            conexion.Open();
            return comando.ExecuteNonQuery();
        }

        // EQUIPOS: se asume que IdEquipo es IDENTITY y que IdDeposito es la FK.
        public int GuardarEquipo(Equipo equipo)
        {
            const string consulta = @"INSERT INTO Equipos
                (Nombre, Tipo, Estado, IdDeposito, Observaciones)
                VALUES (@Nombre, @Tipo, @Estado, @IdDeposito, @Observaciones)";
            using SqlConnection conexion = new SqlConnection(Constantes.CONNECTION_STRING);
            using SqlCommand comando = new SqlCommand(consulta, conexion);
            comando.Parameters.AddWithValue("@Nombre", equipo.Nombre);
            comando.Parameters.AddWithValue("@Tipo", equipo.Tipo);
            comando.Parameters.AddWithValue("@Estado", equipo.Estado);
            comando.Parameters.AddWithValue("@IdDeposito", equipo.DepositoId);
            comando.Parameters.AddWithValue("@Observaciones", equipo.Observaciones);
            conexion.Open();
            return comando.ExecuteNonQuery();
        }

        public DataTable ListarEquipos()
        {
            const string consulta = @"SELECT e.IdEquipo, e.Nombre, e.Tipo, e.Estado,
                e.IdDeposito, d.Nombre AS Deposito, e.Observaciones
                FROM Equipos e
                INNER JOIN Depositos d ON e.IdDeposito = d.IdDeposito
                ORDER BY e.IdEquipo";
            using SqlConnection conexion = new SqlConnection(Constantes.CONNECTION_STRING);
            using SqlDataAdapter adaptador = new SqlDataAdapter(consulta, conexion);
            DataTable tabla = new DataTable();
            adaptador.Fill(tabla);
            return tabla;
        }

        public int ModificarEquipo(Equipo equipo)
        {
            const string consulta = @"UPDATE Equipos SET Nombre=@Nombre, Tipo=@Tipo,
                Estado=@Estado, IdDeposito=@IdDeposito, Observaciones=@Observaciones
                WHERE IdEquipo=@IdEquipo";
            using SqlConnection conexion = new SqlConnection(Constantes.CONNECTION_STRING);
            using SqlCommand comando = new SqlCommand(consulta, conexion);
            comando.Parameters.AddWithValue("@IdEquipo", equipo.Id);
            comando.Parameters.AddWithValue("@Nombre", equipo.Nombre);
            comando.Parameters.AddWithValue("@Tipo", equipo.Tipo);
            comando.Parameters.AddWithValue("@Estado", equipo.Estado);
            comando.Parameters.AddWithValue("@IdDeposito", equipo.DepositoId);
            comando.Parameters.AddWithValue("@Observaciones", equipo.Observaciones);
            conexion.Open();
            return comando.ExecuteNonQuery();
        }

        public int EliminarEquipo(int idEquipo)
        {
            using SqlConnection conexion = new SqlConnection(Constantes.CONNECTION_STRING);
            using SqlCommand comando = new SqlCommand(
                "DELETE FROM Equipos WHERE IdEquipo=@IdEquipo", conexion);
            comando.Parameters.AddWithValue("@IdEquipo", idEquipo);
            conexion.Open();
            return comando.ExecuteNonQuery();
        }
    }
}
