using Datos;
using Entities;

namespace Interfaz;

public partial class EquiposForm : Form
{
    private readonly DatosGestion datos = new DatosGestion();
    private int idSeleccionado = 0;

    public EquiposForm()
    {
        InitializeComponent();

        cmbEstado.Items.AddRange(new object[] { "Disponible", "Alquilado", "En mantenimiento" });
        cmbEstado.SelectedIndex = 0;

        btnGuardar.Click += (s, e) => Guardar();
        btnModificar.Click += (s, e) => Modificar();
        btnEliminar.Click += (s, e) => Eliminar();
        btnLimpiar.Click += (s, e) => Limpiar();
        btnActualizar.Click += (s, e) => ActualizarDatos();
        grilla.SelectionChanged += (s, e) => SeleccionarEquipo();

        ActualizarDatos();
    }

    private void CargarDepositos()
    {
        List<Deposito> depositos = datos.ListarDepositos();
        cmbDeposito.DataSource = null;
        cmbDeposito.DisplayMember = "Nombre";
        cmbDeposito.ValueMember = "Id";
        cmbDeposito.DataSource = depositos;

        if (depositos.Count == 0)
            cmbDeposito.SelectedIndex = -1;
    }

    private void CargarGrilla()
    {
        grilla.DataSource = datos.ListarEquipos();
        grilla.ClearSelection();
    }

    private void ActualizarDatos()
    {
        try
        {
            CargarDepositos();
            CargarGrilla();
        }
        catch (Exception ex)
        {
            MessageBox.Show("No se pudieron cargar los equipos o depósitos desde SQL Server.\n\n" + ex.Message,
                "Error de base de datos", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void Guardar()
    {
        if (string.IsNullOrWhiteSpace(txtNombre.Text) ||
            string.IsNullOrWhiteSpace(txtTipo.Text))
        {
            MessageBox.Show("El nombre y el tipo son obligatorios.");
            return;
        }

        if (cmbDeposito.SelectedValue == null)
        {
            MessageBox.Show("Primero debe registrar un depósito.");
            return;
        }

        try
        {
            Equipo equipo = new Equipo
            {
                Nombre = txtNombre.Text.Trim(),
                Tipo = txtTipo.Text.Trim(),
                Estado = cmbEstado.Text,
                DepositoId = Convert.ToInt32(cmbDeposito.SelectedValue),
                IdDeposito = Convert.ToInt32(cmbDeposito.SelectedValue),
                Observaciones = txtObservaciones.Text.Trim()
            };

            if (datos.GuardarEquipo(equipo) > 0)
            {
                MessageBox.Show("Equipo guardado correctamente.");
                Limpiar();
                CargarGrilla();
            }
            else
                MessageBox.Show("No se pudo guardar el equipo.");
        }
        catch (Exception ex)
        {
            MessageBox.Show("Error al guardar el equipo en SQL Server.\n\n" + ex.Message,
                "Error de base de datos", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void Modificar()
    {
        if (idSeleccionado == 0)
        {
            MessageBox.Show("Seleccione un equipo de la lista.");
            return;
        }
        if (string.IsNullOrWhiteSpace(txtNombre.Text) ||
            string.IsNullOrWhiteSpace(txtTipo.Text))
        {
            MessageBox.Show("El nombre y el tipo son obligatorios.");
            return;
        }
        if (cmbDeposito.SelectedValue == null)
        {
            MessageBox.Show("Seleccione un depósito.");
            return;
        }

        try
        {
            Equipo equipo = new Equipo
            {
                Id = idSeleccionado,
                Nombre = txtNombre.Text.Trim(),
                Tipo = txtTipo.Text.Trim(),
                Estado = cmbEstado.Text,
                DepositoId = Convert.ToInt32(cmbDeposito.SelectedValue),
                IdDeposito = Convert.ToInt32(cmbDeposito.SelectedValue),
                Observaciones = txtObservaciones.Text.Trim()
            };

            if (datos.ModificarEquipo(equipo) > 0)
            {
                MessageBox.Show("Equipo modificado correctamente.");
                Limpiar();
                CargarGrilla();
            }
            else
                MessageBox.Show("No se encontró el equipo para modificar.");
        }
        catch (Exception ex)
        {
            MessageBox.Show("Error al modificar el equipo.\n\n" + ex.Message);
        }
    }

    private void Eliminar()
    {
        if (idSeleccionado == 0)
        {
            MessageBox.Show("Seleccione un equipo de la lista.");
            return;
        }

        DialogResult respuesta = MessageBox.Show(
            "¿Está seguro de eliminar el equipo seleccionado?",
            "Confirmar eliminación", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

        if (respuesta != DialogResult.Yes)
            return;

        try
        {
            if (datos.EliminarEquipo(idSeleccionado) > 0)
            {
                MessageBox.Show("Equipo eliminado correctamente.");
                Limpiar();
                CargarGrilla();
            }
            else
                MessageBox.Show("No se encontró el equipo para eliminar.");
        }
        catch (Exception ex)
        {
            MessageBox.Show("Error al eliminar el equipo.\n\n" + ex.Message);
        }
    }

    private void SeleccionarEquipo()
    {
        if (grilla.CurrentRow == null || grilla.CurrentRow.IsNewRow)
            return;

        object? valorId = grilla.CurrentRow.Cells["IdEquipo"].Value;
        if (valorId == null || valorId == DBNull.Value)
            return;

        idSeleccionado = Convert.ToInt32(valorId);
        txtNombre.Text = Convert.ToString(grilla.CurrentRow.Cells["Nombre"].Value) ?? "";
        txtTipo.Text = Convert.ToString(grilla.CurrentRow.Cells["Tipo"].Value) ?? "";
        cmbEstado.Text = Convert.ToString(grilla.CurrentRow.Cells["Estado"].Value) ?? "Disponible";

        object? valorDeposito = grilla.CurrentRow.Cells["IdDeposito"].Value;
        if (valorDeposito != null && valorDeposito != DBNull.Value)
            cmbDeposito.SelectedValue = Convert.ToInt32(valorDeposito);

        txtObservaciones.Text = Convert.ToString(grilla.CurrentRow.Cells["Observaciones"].Value) ?? "";
    }

    private void Limpiar()
    {
        idSeleccionado = 0;
        txtNombre.Clear();
        txtTipo.Clear();
        txtObservaciones.Clear();

        if (cmbEstado.Items.Count > 0)
            cmbEstado.SelectedIndex = 0;

        if (cmbDeposito.Items.Count > 0)
            cmbDeposito.SelectedIndex = 0;

        grilla.ClearSelection();
    }
}
