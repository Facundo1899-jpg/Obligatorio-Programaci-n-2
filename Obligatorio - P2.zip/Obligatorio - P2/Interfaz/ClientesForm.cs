using Entities;
using Persistencia;
using Datos;
namespace Interfaz;
using System.Data;
using Microsoft.Data.SqlClient;

public partial class ClientesForm : Form
{
    private readonly RepositorioJson<Cliente> repositorio = new("clientes.json");



    private int idSeleccionado = 0;

    public ClientesForm()
    {
        InitializeComponent();
        cmbTipo.Items.AddRange(new object[] { "Particular", "Empresa" , "Organizacion" });
        cmbTipo.SelectedIndex = 0;
        btnGuardar.Click += (s, e) => Guardar();
        btnModificar.Click += (s, e) => Modificar();
        btnEliminar.Click += (s, e) => Eliminar();
        btnLimpiar.Click += (s, e) => Limpiar();
        grilla.SelectionChanged += (s, e) => SeleccionarCliente();
        CargarGrilla();
    }

    private void CargarGrilla()
    {
        grilla.DataSource = null;
        grilla.DataSource = repositorio.ObtenerTodos();
        grilla.ClearSelection();
    }

    private void Guardar()
    {
        if (txtDocumento.Text.Trim() == "" || txtNombre.Text.Trim() == "")
        {
            return;
        }

        List<Cliente> clientes = repositorio.ObtenerTodos();

        bool existe = clientes.Any(c => c.Documento == txtDocumento.Text.Trim());

        if (existe)
        {
            return;
        }

        int nuevoId = 1;

        if (clientes.Count > 0)
            nuevoId = clientes.Max(c => c.Id) + 1;

        Cliente cliente = new Cliente();
        cliente.Id = nuevoId;
        cliente.Tipo = cmbTipo.Text;
        cliente.Documento = txtDocumento.Text.Trim();
        cliente.Nombre = txtNombre.Text.Trim();
        cliente.Telefono = txtTelefono.Text.Trim();
        cliente.Email = txtEmail.Text.Trim();
        cliente.Direccion = txtDireccion.Text.Trim();

        clientes.Add(cliente);
        repositorio.Guardar(clientes);

        CargarGrilla();
        Limpiar();

    }

    private void Modificar()
    {
        List<Cliente> clientes = repositorio.ObtenerTodos();
        Cliente cliente = clientes.FirstOrDefault(c => c.Id == idSeleccionado);

        if (cliente == null)
        {
            return;
        }

        if (txtDocumento.Text.Trim() == "" || txtNombre.Text.Trim() == "")
        {
            return;
        }

        bool documentoRepetido = clientes.Any(c =>
            c.Id != idSeleccionado && c.Documento == txtDocumento.Text.Trim());

        if (documentoRepetido)
        {
            return;
        }

        cliente.Tipo = cmbTipo.Text;
        cliente.Documento = txtDocumento.Text.Trim();
        cliente.Nombre = txtNombre.Text.Trim();
        cliente.Telefono = txtTelefono.Text.Trim();
        cliente.Email = txtEmail.Text.Trim();
        cliente.Direccion = txtDireccion.Text.Trim();

        repositorio.Guardar(clientes);
        CargarGrilla();
        Limpiar();
    }

    private void Eliminar()
    {
        if (idSeleccionado == 0)
        {
            return;
        }
    }

    private void SeleccionarCliente()
    {
        if (grilla.CurrentRow == null)
            return;

        if (grilla.CurrentRow.DataBoundItem is Cliente cliente)
        {
            idSeleccionado = cliente.Id;
            cmbTipo.Text = cliente.Tipo;
            txtDocumento.Text = cliente.Documento;
            txtNombre.Text = cliente.Nombre;
            txtTelefono.Text = cliente.Telefono;
            txtEmail.Text = cliente.Email;
            txtDireccion.Text = cliente.Direccion;
        }
    }

    private void Limpiar()
    {
        idSeleccionado = 0;
        cmbTipo.SelectedIndex = 0;
        txtDocumento.Clear();
        txtNombre.Clear();
        txtTelefono.Clear();
        txtEmail.Clear();
        txtDireccion.Clear();
        grilla.ClearSelection();
    }

    private void btnGuardar_Click(object sender, EventArgs e)
    {
        if (txtDocumento.Text == "" ||
            txtNombre.Text == "" ||
            txtTelefono.Text == "" ||
            txtEmail.Text == "" ||
            txtDireccion.Text == "")
        {
            MessageBox.Show("Debe completar todos los campos");
            return;
        }




        Cliente cliente = new Cliente();
        cliente.Tipo = cmbTipo.Text;
        cliente.Documento = txtDocumento.Text;
        cliente.Nombre = txtNombre.Text;
        cliente.Telefono = txtTelefono.Text;
        cliente.Email = txtEmail.Text;
        cliente.Direccion = txtDireccion.Text;

        DatosGestion datos = new DatosGestion();
        int resultado = datos.GuardarCliente(cliente);
        if (resultado == -1)
        {
            MessageBox.Show("El cliente ya fue ingresasdo.",
                "Cliente Duplicado",
                MessageBoxButtons.OK,
                MessageBoxIcon.Warning);
            return;
        }
        dgvClientes.DataSource = datos.ListarClientes();
        MessageBox.Show("El cliente fue guardado con exito");
    }

    private void ClientesForm_Load(object sender, EventArgs e)
    {
        DatosGestion datos = new DatosGestion();
        dgvClientes.DataSource = datos.ListarClientes();
    }

    private void btnEliminar_Click(object sender, EventArgs e)
    {
        if (dgvClientes.CurrentRow == null)
        {
            MessageBox.Show("Seleccione un cliente");
            return;
        }

        int idCliente = Convert.ToInt32(dgvClientes.CurrentRow.Cells["IdCliente"].Value);

        DialogResult respuesta = MessageBox.Show("¿Esta seguro que desea eliminar este cliente?",
            "Confirmar eliminacion", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

        if (respuesta == DialogResult.Yes)
        {
            DatosGestion datos = new DatosGestion();
            int resultado = datos.EliminarCliente(idCliente);

            if (resultado > 0)
            {
                MessageBox.Show("Cliente eliminado correctamente.");
                dgvClientes.DataSource = datos.ListarClientes();
            }
            else
            {
                MessageBox.Show("No se contro el cliente para eliminar." + resultado);
            }
        }
    }

    private void dgvClientes_CellClick(object sender, DataGridViewCellEventArgs e)
    {

        if (e.RowIndex >= 0)
        {
            DataGridViewRow fila = dgvClientes.Rows[e.RowIndex];
            txtDocumento.Text = fila.Cells["Documento"].Value.ToString();
            txtDireccion.Text = fila.Cells["Direccion"].Value.ToString();
            txtEmail.Text = fila.Cells["Email"].Value.ToString();
            txtNombre.Text = fila.Cells["Nombre"].Value.ToString();
            txtTelefono.Text = fila.Cells["Telefono"].Value.ToString();
            cmbTipo.Text = fila.Cells["Tipo"].Value.ToString();
        }
    }

    private void btnModificar_Click(object sender, EventArgs e)
    {
        if (dgvClientes.CurrentRow == null)
        {
            MessageBox.Show("Debe seleccionar un cliente de la lista.");
            return;
        }
        Cliente cliente = new Cliente();

        cliente.Id = Convert.ToInt32(dgvClientes.CurrentRow.Cells["IdCliente"].Value);
        MessageBox.Show("ID del cliente: " + cliente.Id);
        cliente.Tipo = cmbTipo.Text;
        cliente.Documento = txtDocumento.Text;
        cliente.Nombre = txtNombre.Text;
        cliente.Email = txtEmail.Text;
        cliente.Telefono = txtTelefono.Text;
        cliente.Direccion = txtDireccion.Text;

        DatosGestion datos = new DatosGestion();
        int resultado = datos.ModificarCliente(cliente);

    }

    private void btnActualizar_Click(object sender, EventArgs e)
    {
        DatosGestion datos = new DatosGestion();
        dgvClientes.DataSource = datos.ListarClientes();
    }


}
