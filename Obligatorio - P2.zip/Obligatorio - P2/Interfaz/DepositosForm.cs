using Datos;
using Entities;

namespace Interfaz;

public partial class DepositosForm : Form
{
    private readonly DatosGestion datos = new DatosGestion();
    private int idSeleccionado = 0;

    public DepositosForm()
    {
        InitializeComponent();

        // El botón Guardar ya está conectado a btnGuardar_Click desde el Designer.
        btnModificar.Click += (s, e) => Modificar();
        btnEliminar.Click += (s, e) => Eliminar();
        btnLimpiar.Click += (s, e) => Limpiar();
        btnActualizar.Click += (s, e) => CargarGrilla();
        grilla.SelectionChanged += (s, e) => SeleccionarDeposito();

        CargarGrilla();
    }

    private void CargarGrilla()
    {
        try
        {
            grilla.DataSource = datos.ListarDepositosTabla();
            grilla.ClearSelection();
        }
        catch (Exception ex)
        {
            MessageBox.Show("No se pudieron cargar los depósitos desde SQL Server.\n\n" + ex.Message,
                "Error de base de datos", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void btnGuardar_Click(object sender, EventArgs e)
    {
        if (string.IsNullOrWhiteSpace(txtNombre.Text) ||
            string.IsNullOrWhiteSpace(txtUbicacion.Text))
        {
            MessageBox.Show("El nombre y la ubicación son obligatorios.");
            return;
        }

        try
        {
            Deposito deposito = new Deposito
            {
                Nombre = txtNombre.Text.Trim(),
                Ubicacion = txtUbicacion.Text.Trim(),
                Observaciones = txtObservaciones.Text.Trim()
            };

            int resultado = datos.GuardarDeposito(deposito);
            if (resultado > 0)
            {
                MessageBox.Show("Depósito guardado correctamente.");
                Limpiar();
                CargarGrilla();
            }
            else
            {
                MessageBox.Show("No se pudo guardar el depósito.");
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show("Error al guardar el depósito en SQL Server.\n\n" + ex.Message,
                "Error de base de datos", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void Modificar()
    {
        if (idSeleccionado == 0)
        {
            MessageBox.Show("Seleccione un depósito de la lista.");
            return;
        }
        if (string.IsNullOrWhiteSpace(txtNombre.Text) ||
            string.IsNullOrWhiteSpace(txtUbicacion.Text))
        {
            MessageBox.Show("El nombre y la ubicación son obligatorios.");
            return;
        }

        try
        {
            Deposito deposito = new Deposito
            {
                Id = idSeleccionado,
                Nombre = txtNombre.Text.Trim(),
                Ubicacion = txtUbicacion.Text.Trim(),
                Observaciones = txtObservaciones.Text.Trim()
            };

            if (datos.ModificarDeposito(deposito) > 0)
            {
                MessageBox.Show("Depósito modificado correctamente.");
                Limpiar();
                CargarGrilla();
            }
            else
                MessageBox.Show("No se encontró el depósito para modificar.");
        }
        catch (Exception ex)
        {
            MessageBox.Show("Error al modificar el depósito.\n\n" + ex.Message);
        }
    }

    private void Eliminar()
    {
        if (idSeleccionado == 0)
        {
            MessageBox.Show("Seleccione un depósito de la lista.");
            return;
        }

        DialogResult respuesta = MessageBox.Show(
            "¿Está seguro de eliminar el depósito seleccionado?",
            "Confirmar eliminación", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

        if (respuesta != DialogResult.Yes)
            return;

        try
        {
            int resultado = datos.EliminarDeposito(idSeleccionado);
            if (resultado > 0)
            {
                MessageBox.Show("Depósito eliminado correctamente.");
                Limpiar();
                CargarGrilla();
            }
            else
                MessageBox.Show("No se encontró el depósito para eliminar.");
        }
        catch (Exception ex)
        {
            MessageBox.Show("No se pudo eliminar el depósito. Compruebe que no tenga equipos asociados.\n\n" + ex.Message,
                "No se puede eliminar", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }

    private void SeleccionarDeposito()
    {
        if (grilla.CurrentRow == null || grilla.CurrentRow.IsNewRow)
            return;

        object? valor = grilla.CurrentRow.Cells["IdDeposito"].Value;
        if (valor == null || valor == DBNull.Value)
            return;

        idSeleccionado = Convert.ToInt32(valor);
        txtNombre.Text = Convert.ToString(grilla.CurrentRow.Cells["Nombre"].Value) ?? "";
        txtUbicacion.Text = Convert.ToString(grilla.CurrentRow.Cells["Ubicacion"].Value) ?? "";
        txtObservaciones.Text = Convert.ToString(grilla.CurrentRow.Cells["Observaciones"].Value) ?? "";
    }

    private void Limpiar()
    {
        idSeleccionado = 0;
        txtNombre.Clear();
        txtUbicacion.Clear();
        txtObservaciones.Clear();
        grilla.ClearSelection();
    }
}
